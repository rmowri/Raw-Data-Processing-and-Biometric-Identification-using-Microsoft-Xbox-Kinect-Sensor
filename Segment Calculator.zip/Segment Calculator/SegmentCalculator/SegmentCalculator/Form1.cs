﻿using Microsoft.Kinect;
using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Imaging;
using System.Linq;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace SegmentCalculator
{
    public partial class Form1 : Form
    {
        string connection = ConfigurationManager.ConnectionStrings["SegmentCalConString"].ConnectionString;
        SqlConnection con = new SqlConnection();

        KinectSensor _sensor;
        MultiSourceFrameReader _reader;
        IList<Body> _bodies;
        Bitmap currentImage;
        int CFCounter = 0;
        int BFCounter = 0;
        private BindingSource bindingSource1;
        private bool clickedWide;
        ulong TrackingNo;
        private readonly Queue<double> _Height = new Queue<double>();
        private readonly Queue<double> _Torso = new Queue<double>();
        private readonly Queue<double> _Neck = new Queue<double>();
        private readonly Queue<double> _LeftUpperArm = new Queue<double>();
        private readonly Queue<double> _LeftForeArm = new Queue<double>();
        private readonly Queue<double> _RightUpperArm = new Queue<double>();
        private readonly Queue<double> _RightForeArm = new Queue<double>();
        private readonly Queue<double> _UpperSpine = new Queue<double>();
        private readonly Queue<double> _LowerSpine = new Queue<double>();
        private readonly Queue<double> _LeftThigh = new Queue<double>();
        private readonly Queue<double> _RightThigh = new Queue<double>();
        private readonly Queue<double> _LeftLowerLeg = new Queue<double>();
        private readonly Queue<double> _RightLowerLeg = new Queue<double>();
        private readonly Queue<double> _LegLength = new Queue<double>();

        public Form1()
        {
            this.Load += new EventHandler(Form1_Load);
        }

        public void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(connection);
            InitializeComponent();
            bindingSource1 = new System.Windows.Forms.BindingSource();
            bindingSource1.BindingComplete += new BindingCompleteEventHandler(bindingSource1_BindingComplete);
        }
        private void bindingSource1_BindingComplete(object sender, BindingCompleteEventArgs e)
        {
            if (e.BindingCompleteContext == BindingCompleteContext.DataSourceUpdate
                && e.Exception == null)
                e.Binding.BindingManagerBase.EndCurrentEdit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if(connect.Text == "CONNECT")
            {
                _sensor = KinectSensor.GetDefault();
                if (_sensor != null)
                {
                    _sensor.Open();
                    _reader = _sensor.OpenMultiSourceFrameReader(FrameSourceTypes.Color | FrameSourceTypes.Depth | FrameSourceTypes.Infrared | FrameSourceTypes.Body);
                    _reader.MultiSourceFrameArrived += Reader_MultiSourceFrameArrived;
                }
                connect.Text = "DISCONNECT";
            } else if(connect.Text == "DISCONNECT") {

                pb.Image = null;
                BFCounter = 0;
                BF.Text = BFCounter.ToString();
                CFCounter = 0;
                CF.Text = CFCounter.ToString();
                if (_reader != null)
                {
                    _reader.Dispose();
                }

                if (_sensor != null)
                {
                    _sensor.Close();
                }
                connect.Text = "CONNECT";
            }
            
        }

        private void Form1_Closed(object sender, FormClosedEventArgs e)
        {
            if (_reader != null)
            {
                _reader.Dispose();
            }

            if (_sensor != null)
            {
                _sensor.Close();
            }
        }

        public void Reader_MultiSourceFrameArrived(object sender, MultiSourceFrameArrivedEventArgs e)
        {
            var reference = e.FrameReference.AcquireFrame();
            //Color and Body
            bool bodyExists = false;
            using (var colorFrame = reference.ColorFrameReference.AcquireFrame())
            using (var bodyFrame = reference.BodyFrameReference.AcquireFrame())
            {
                if (colorFrame != null)
                {                    
                    pb.Image = ColorImageFrameToBitmap(colorFrame);
                    currentImage = ColorImageFrameToBitmap(colorFrame);
                    CFCounter++;
                    CF.Text = CFCounter.ToString();
                }

                if (bodyFrame != null)
                {
                    BFCounter++;
                    BF.Text = BFCounter.ToString();
                    _bodies = new Body[bodyFrame.BodyFrameSource.BodyCount];
                    bodyFrame.GetAndRefreshBodyData(_bodies);
                    foreach (var body in _bodies)
                    {
                        float SpineMid_x = body.Joints[JointType.SpineMid].Position.X;
                        float SpineMid_y = body.Joints[JointType.SpineMid].Position.Y;
                        float SpineMid_z = body.Joints[JointType.SpineMid].Position.Z;
                        if (SpineMid_x != 0 && SpineMid_y != 0 && SpineMid_z != 0)
                        {
                            bodyExists = true;
                            //BE.Text = "TRUE";
                        }
                        else
                        {
                            //BE.Text = "FALSE";
                        }
                    }
                }
            }

            //Process
            if (bodyExists) //color frame with body frame
            {
                foreach (var body in _bodies)
                {
                    if (body.IsTracked)
                    {
                        populate(body);
                    }
                }
            }
            else
            {
                P1ID.Text = "";
                trackingID.Text = "";
            }
        }
       
        public void populate(Body body)
        {
            populateJointInfo(body);
            populateSegmentInfo(body);
            
        }

        public static double Length(Joint p1, Joint p2)
        {
            return Math.Sqrt(
                Math.Pow(p1.Position.X - p2.Position.X, 2) +
                Math.Pow(p1.Position.Y - p2.Position.Y, 2) +
                Math.Pow(p1.Position.Z - p2.Position.Z, 2));
        }


        public static double Length(params Joint[] joints)
        {
            double length = 0;

            for (int index = 0; index < joints.Length - 1; index++)
            {
                length += Length(joints[index], joints[index + 1]);
            }

            return length;
        }

        private int NumberOfTrackedJoints(params Joint[] joints)
        {
            int trackedJoints = 0;

            foreach (var joint in joints)
            {
                if (joint.TrackingState == TrackingState.Tracked)
                {
                    trackedJoints++;
                }
            }

            return trackedJoints;
        }

        public Bitmap ColorImageFrameToBitmap(ColorFrame frame)
        {
            int width = frame.FrameDescription.Width;
            int height = frame.FrameDescription.Height;
            int pixelDataLength = width * height * ((32 + 7) / 8);

            byte[] pixels = new byte[width * height * ((32 + 7) / 8)];

            if (frame.RawColorImageFormat == ColorImageFormat.Bgra)
            {
                frame.CopyRawFrameDataToArray(pixels);
            }
            else
            {
                frame.CopyConvertedFrameDataToArray(pixels, ColorImageFormat.Bgra);
            }

            PixelFormat format = PixelFormat.Format32bppRgb;
            Rectangle colorRect = new Rectangle(0, 0, width, height);
            ImageLockMode writeOnly = ImageLockMode.WriteOnly;

            Bitmap bitmapFrame = new Bitmap(width, height);

            BitmapData bitmapData = bitmapFrame.LockBits(colorRect, writeOnly, format);

            IntPtr stride = bitmapData.Scan0;

            Marshal.Copy(pixels, 0, stride, pixelDataLength);

            bitmapFrame.UnlockBits(bitmapData);

            return bitmapFrame;
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            clickedWide = true;
            int x = 200;
            int y = 200;
            Form2 form2 = new Form2(currentImage);
            form2.Visible = true;

            form2.SetDesktopLocation(x, y);
            x += 30;
            y += 30;

            pb.Image = form2.SelectedImage;

        }

        private List<double> ExponentialWeightedAvg(List<double> values)
        {
            List<double> output = new List<double>();
            _Height.Enqueue(values[0]);
            _Torso.Enqueue(values[1]);
            _Neck.Enqueue(values[2]);
            _LeftUpperArm.Enqueue(values[3]);
            _LeftForeArm.Enqueue(values[4]);
            _RightUpperArm.Enqueue(values[5]);
            _RightForeArm.Enqueue(values[6]);
            _UpperSpine.Enqueue(values[7]);
            _LowerSpine.Enqueue(values[8]);
            _LeftThigh.Enqueue(values[9]);
            _RightThigh.Enqueue(values[10]);
            _LeftLowerLeg.Enqueue(values[11]);
            _RightLowerLeg.Enqueue(values[12]);
            _LegLength.Enqueue(values[13]);

            double _HeightValue = ExponentialMovingAverage(_Height.ToArray(), 0.9);
            double _TorsoValue = ExponentialMovingAverage(_Torso.ToArray(), 0.9);
            double _NeckValue = ExponentialMovingAverage(_Neck.ToArray(), 0.9);
            double _LeftUpperArmValue = ExponentialMovingAverage(_LeftUpperArm.ToArray(), 0.9);
            double _LeftForeArmValue = ExponentialMovingAverage(_LeftForeArm.ToArray(), 0.9);
            double _RightUpperArmValue = ExponentialMovingAverage(_RightUpperArm.ToArray(), 0.9);
            double _RightForeArmValue = ExponentialMovingAverage(_RightForeArm.ToArray(), 0.9);
            double _UpperSpineValue = ExponentialMovingAverage(_UpperSpine.ToArray(), 0.9);
            double _LowerSpineValue = ExponentialMovingAverage(_LowerSpine.ToArray(), 0.9);
            double _LeftThighValue = ExponentialMovingAverage(_LeftThigh.ToArray(), 0.9);
            double _RightThighValue = ExponentialMovingAverage(_RightThigh.ToArray(), 0.9);
            double _LeftLowerLegValue = ExponentialMovingAverage(_LeftLowerLeg.ToArray(), 0.9);
            double _RightLowerLegValue = ExponentialMovingAverage(_RightLowerLeg.ToArray(), 0.9);
            double _LegLengthValue = ExponentialMovingAverage(_LegLength.ToArray(), 0.9);


            output.Add(_HeightValue);
            output.Add(_TorsoValue);
            output.Add(_NeckValue);
            output.Add(_LeftUpperArmValue);
            output.Add(_LeftForeArmValue);
            output.Add(_RightUpperArmValue);
            output.Add(_RightForeArmValue);
            output.Add(_UpperSpineValue);
            output.Add(_LowerSpineValue);
            output.Add(_LeftThighValue);
            output.Add(_RightThighValue);
            output.Add(_LeftLowerLegValue);
            output.Add(_RightLowerLegValue);
            output.Add(_LegLengthValue);

            return output;
        }

        public double ExponentialMovingAverage(double[] data, double baseValue)
        {
            double numerator = 0;
            double denominator = 0;

            double average = data.Sum();
            average /= data.Length;

            for (int i = 0; i < data.Length; ++i)
            {
                numerator += data[i] * Math.Pow(baseValue, data.Length - i - 1);
                denominator += Math.Pow(baseValue, data.Length - i - 1);
            }

            numerator += average * Math.Pow(baseValue, data.Length);
            denominator += Math.Pow(baseValue, data.Length);

            return numerator / denominator;
        }

        public void populateJointInfo(Body body)
        {
            TrackingNo = body.TrackingId;
            P1ID.Text = TrackingNo.ToString();
            trackingID.Text = TrackingNo.ToString();
            String Spine_Base_X = (body.Joints[JointType.SpineBase].Position.X * 100).ToString();
            String Spine_Base_Y = (body.Joints[JointType.SpineBase].Position.Y * 100).ToString();
            String Spine_Base_Z = (body.Joints[JointType.SpineBase].Position.Z * 100).ToString();
            String Spine_Mid_X = (body.Joints[JointType.SpineMid].Position.X * 100).ToString();
            String Spine_Mid_Y = (body.Joints[JointType.SpineMid].Position.Y * 100).ToString();
            String Spine_Mid_Z = (body.Joints[JointType.SpineMid].Position.Z * 100).ToString();
            String Neck_X = (body.Joints[JointType.Neck].Position.X * 100).ToString();
            String Neck_Y = (body.Joints[JointType.Neck].Position.Y * 100).ToString();
            String Neck_Z = (body.Joints[JointType.Neck].Position.Z * 100).ToString();
            String Head_X = (body.Joints[JointType.Head].Position.X * 100).ToString();
            String Head_Y = (body.Joints[JointType.Head].Position.Y * 100).ToString();
            String Head_Z = (body.Joints[JointType.Head].Position.Z * 100).ToString();
            String Shoulder_Left_X = (body.Joints[JointType.ShoulderLeft].Position.X * 100).ToString();
            String Shoulder_Left_Y = (body.Joints[JointType.ShoulderLeft].Position.Y * 100).ToString();
            String Shoulder_Left_Z = (body.Joints[JointType.ShoulderLeft].Position.Z * 100).ToString();
            String Elbow_Left_X = (body.Joints[JointType.ElbowLeft].Position.X * 100).ToString();
            String Elbow_Left_Y = (body.Joints[JointType.ElbowLeft].Position.Y * 100).ToString();
            String Elbow_Left_Z = (body.Joints[JointType.ElbowLeft].Position.Z * 100).ToString();
            String Wrist_Left_X = (body.Joints[JointType.WristLeft].Position.X * 100).ToString();
            String Wrist_Left_Y = (body.Joints[JointType.WristLeft].Position.Y * 100).ToString();
            String Wrist_Left_Z = (body.Joints[JointType.WristLeft].Position.Z * 100).ToString();
            String Hand_Tip_Left_X = (body.Joints[JointType.HandTipLeft].Position.X * 100).ToString();
            String Hand_Tip_Left_Y = (body.Joints[JointType.HandTipLeft].Position.Y * 100).ToString();
            String Hand_Tip_Left_Z = (body.Joints[JointType.HandTipLeft].Position.Z * 100).ToString();
            String Shoulder_Right_X = (body.Joints[JointType.ShoulderRight].Position.X * 100).ToString();
            String Shoulder_Right_Y = (body.Joints[JointType.ShoulderRight].Position.Y * 100).ToString();
            String Shoulder_Right_Z = (body.Joints[JointType.ShoulderRight].Position.Z * 100).ToString();
            String Elbow_Right_X = (body.Joints[JointType.ElbowRight].Position.X * 100).ToString();
            String Elbow_Right_Y = (body.Joints[JointType.ElbowRight].Position.Y * 100).ToString();
            String Elbow_Right_Z = (body.Joints[JointType.ElbowRight].Position.Z * 100).ToString();
            String Wrist_Right_X = (body.Joints[JointType.WristRight].Position.X * 100).ToString();
            String Wrist_Right_Y = (body.Joints[JointType.WristRight].Position.Y * 100).ToString();
            String Wrist_Right_Z = (body.Joints[JointType.WristRight].Position.Z * 100).ToString();
            String Hand_Tip_Right_X = (body.Joints[JointType.HandTipRight].Position.X * 100).ToString();
            String Hand_Tip_Right_Y = (body.Joints[JointType.HandTipRight].Position.Y * 100).ToString();
            String Hand_Tip_Right_Z = (body.Joints[JointType.HandTipRight].Position.Z * 100).ToString();
            String Hip_Left_X = (body.Joints[JointType.HipLeft].Position.X * 100).ToString();
            String Hip_Left_Y = (body.Joints[JointType.HipLeft].Position.Y * 100).ToString();
            String Hip_Left_Z = (body.Joints[JointType.HipLeft].Position.Z * 100).ToString();
            String Knee_Left_X = (body.Joints[JointType.KneeLeft].Position.X * 100).ToString();
            String Knee_Left_Y = (body.Joints[JointType.KneeLeft].Position.Y * 100).ToString();
            String Knee_Left_Z = (body.Joints[JointType.KneeLeft].Position.Z * 100).ToString();
            String Ankle_Left_X = (body.Joints[JointType.AnkleLeft].Position.X * 100).ToString();
            String Ankle_Left_Y = (body.Joints[JointType.AnkleLeft].Position.Y * 100).ToString();
            String Ankle_Left_Z = (body.Joints[JointType.AnkleLeft].Position.Z * 100).ToString();
            String Foot_Left_X = (body.Joints[JointType.FootLeft].Position.X * 100).ToString();
            String Foot_Left_Y = (body.Joints[JointType.FootLeft].Position.Y * 100).ToString();
            String Foot_Left_Z = (body.Joints[JointType.FootLeft].Position.Z * 100).ToString();
            String Hip_Right_X = (body.Joints[JointType.HipRight].Position.X * 100).ToString();
            String Hip_Right_Y = (body.Joints[JointType.HipRight].Position.Y * 100).ToString();
            String Hip_Right_Z = (body.Joints[JointType.HipRight].Position.Z * 100).ToString();
            String Knee_Right_X = (body.Joints[JointType.KneeRight].Position.X * 100).ToString();
            String Knee_Right_Y = (body.Joints[JointType.KneeRight].Position.Y * 100).ToString();
            String Knee_Right_Z = (body.Joints[JointType.KneeRight].Position.Z * 100).ToString();
            String Ankle_Right_X = (body.Joints[JointType.AnkleRight].Position.X * 100).ToString();
            String Ankle_Right_Y = (body.Joints[JointType.AnkleRight].Position.Y * 100).ToString();
            String Ankle_Right_Z = (body.Joints[JointType.AnkleRight].Position.Z * 100).ToString();
            String Foot_Right_X = (body.Joints[JointType.FootRight].Position.X * 100).ToString();
            String Foot_Right_Y = (body.Joints[JointType.FootRight].Position.Y * 100).ToString();
            String Foot_Right_Z = (body.Joints[JointType.FootRight].Position.Z * 100).ToString();
            String Spine_Shoulder_X = (body.Joints[JointType.SpineShoulder].Position.X * 100).ToString();
            String Spine_Shoulder_Y = (body.Joints[JointType.SpineShoulder].Position.Y * 100).ToString();
            String Spine_Shoulder_Z = (body.Joints[JointType.SpineShoulder].Position.Z * 100).ToString();
            String Thumb_Left_X = (body.Joints[JointType.ThumbLeft].Position.X * 100).ToString();
            String Thumb_Left_Y = (body.Joints[JointType.ThumbLeft].Position.Y * 100).ToString();
            String Thumb_Left_Z = (body.Joints[JointType.ThumbLeft].Position.Z * 100).ToString();
            String Thumb_Right_X = (body.Joints[JointType.ThumbRight].Position.X * 100).ToString();
            String Thumb_Right_Y = (body.Joints[JointType.ThumbRight].Position.Y * 100).ToString();
            String Thumb_Right_Z = (body.Joints[JointType.ThumbRight].Position.Z * 100).ToString();


            SpineBaseX.Text = Spine_Base_X;
            SpineBaseY.Text = Spine_Base_Y;
            SpineBaseZ.Text = Spine_Base_Z;
            SpineMidX.Text = Spine_Mid_X;
            SpineMidY.Text = Spine_Mid_Y;
            SpineMidZ.Text = Spine_Mid_Z;
            NeckX.Text = Neck_X;
            NeckY.Text = Neck_Y;
            NeckZ.Text = Neck_Z;
            HeadX.Text = Head_X;
            HeadY.Text = Head_Y;
            HeadZ.Text = Head_Z;
            ShoulderLeftX.Text = Shoulder_Left_X;
            ShoulderLeftY.Text = Shoulder_Left_Y;
            ShoulderLeftZ.Text = Shoulder_Left_Z;
            ElbowLeftX.Text = Elbow_Left_X;
            ElbowLeftY.Text = Elbow_Left_Y;
            ElbowLeftZ.Text = Elbow_Left_Z;
            WristLeftX.Text = Wrist_Left_X;
            WristLeftY.Text = Wrist_Left_Y;
            WristLeftZ.Text = Wrist_Left_Z;
            HandTipLeftX.Text = Hand_Tip_Left_X;
            HandTipLeftY.Text = Hand_Tip_Left_Y;
            HandTipLeftZ.Text = Hand_Tip_Left_Z;
            ShoulderRightX.Text = Shoulder_Right_X;
            ShoulderRightY.Text = Shoulder_Right_Y;
            ShoulderRightZ.Text = Shoulder_Right_Z;
            ElbowRightX.Text = Elbow_Right_X;
            ElbowRightY.Text = Elbow_Right_Y;
            ElbowRightZ.Text = Elbow_Right_Z;
            WristRightX.Text = Wrist_Right_X;
            WristRightY.Text = Wrist_Right_Y;
            WristRightZ.Text = Wrist_Right_Z;
            HandTipRightX.Text = Hand_Tip_Right_X;
            HandTipRightY.Text = Hand_Tip_Right_Y;
            HandTipRightZ.Text = Hand_Tip_Right_Z;
            HipLeftX.Text = Hip_Left_X;
            HipLeftY.Text = Hip_Left_Y;
            HipLeftZ.Text = Hip_Left_Z;
            KneeLeftX.Text = Knee_Left_X;
            KneeLeftY.Text = Knee_Left_Y;
            KneeLeftZ.Text = Knee_Left_Z;
            AnkleLeftX.Text = Ankle_Left_X;
            AnkleLeftY.Text = Ankle_Left_Y;
            AnkleLeftZ.Text = Ankle_Left_Z;
            FootLeftX.Text = Foot_Left_X;
            FootLeftY.Text = Foot_Left_Y;
            FootLeftZ.Text = Foot_Left_Z;
            HipRightX.Text = Hip_Right_X;
            HipRightY.Text = Hip_Right_Y;
            HipRightZ.Text = Hip_Right_Z;
            KneeRightX.Text = Knee_Right_X;
            KneeRightY.Text = Knee_Right_Y;
            KneeRightZ.Text = Knee_Right_Z;
            AnkleRightX.Text = Ankle_Right_X;
            AnkleRightY.Text = Ankle_Right_Y;
            AnkleRightZ.Text = Ankle_Right_Z;
            FootRightX.Text = Foot_Right_X;
            FootRightY.Text = Foot_Right_Y;
            FootRightZ.Text = Foot_Right_Z;
            SpineShoulderX.Text = Spine_Shoulder_X;
            SpineShoulderY.Text = Spine_Shoulder_Y;
            SpineShoulderZ.Text = Spine_Shoulder_Z;
            ThumbLeftX.Text = Thumb_Left_X;
            ThumbLeftY.Text = Thumb_Left_Y;
            ThumbLeftZ.Text = Thumb_Left_Z;
            ThumbRightX.Text = Thumb_Right_X;
            ThumbRightY.Text = Thumb_Right_Y;
            ThumbRightZ.Text = Thumb_Right_Z;
        }

        public void populateSegmentInfo(Body body)
        {
            //Save all the joint coordinates needed to calculate the 14 static biometrics
            var head = body.Joints[JointType.Head];
            var neck = body.Joints[JointType.Neck];
            var SpineShoulder = body.Joints[JointType.SpineShoulder];
            var ShoulderLeft = body.Joints[JointType.ShoulderLeft];
            var ShoulderRight = body.Joints[JointType.ShoulderRight];
            var elbowleft = body.Joints[JointType.ElbowLeft];
            var elbowright = body.Joints[JointType.ElbowRight];
            var wristleft = body.Joints[JointType.WristLeft];
            var wristright = body.Joints[JointType.WristRight];
            var handleft = body.Joints[JointType.HandLeft];
            var handright = body.Joints[JointType.HandRight];
            var thumbleft = body.Joints[JointType.ThumbLeft];
            var thumbright = body.Joints[JointType.ThumbRight];
            var handtipleft = body.Joints[JointType.HandTipLeft];
            var handtipright = body.Joints[JointType.HandTipRight];
            var SpineMid = body.Joints[JointType.SpineMid];
            var SpineBase = body.Joints[JointType.SpineBase];
            var hipleft = body.Joints[JointType.HipLeft];
            var kneeLeft = body.Joints[JointType.KneeLeft];
            var ankleleft = body.Joints[JointType.AnkleLeft];
            var footleft = body.Joints[JointType.FootLeft];
            var hipright = body.Joints[JointType.HipRight];
            var kneeright = body.Joints[JointType.KneeRight];
            var ankleright = body.Joints[JointType.AnkleRight];
            var footright = body.Joints[JointType.FootRight];

            // Find which leg is tracked more accurately.
            int legLeftTrackedJoints = NumberOfTrackedJoints(hipleft, kneeLeft, ankleleft, footleft);
            int legRightTrackedJoints = NumberOfTrackedJoints(hipright, kneeright, ankleright, footright);

            double LengthofLegsV = 0;
            if (legLeftTrackedJoints > legRightTrackedJoints)
            {
                LengthofLegsV = Length(hipleft, kneeLeft, ankleleft, footleft)*100;

            }
            else
            {
                LengthofLegsV = Length(hipright, kneeright, ankleright, footright)*100;
            }
            LegLength.Text = LengthofLegsV.ToString();

            double LengthofTorso = Length(head, neck, SpineShoulder, SpineMid, SpineBase)*100;
            TorsoValue.Text = LengthofTorso.ToString();

            double HeightV = (LengthofTorso + LengthofLegsV)*100;
            HeightValue.Text = HeightV.ToString();

            double lengthofNeck = Length(head, neck)*100;
            NeckValue.Text = lengthofNeck.ToString();
            double lengthofLeftUpperArm = Length(ShoulderLeft, elbowleft)*100;
            LeftUpperArmValue.Text = lengthofLeftUpperArm.ToString();
            double lengthofLeftForeArm = Length(elbowleft, wristleft)*100;
            LeftForeArmValue.Text = lengthofLeftForeArm.ToString();
            double lengthofRightUpperArm = Length(ShoulderRight, elbowright)*100;
            RightUpperArmValue.Text = lengthofRightUpperArm.ToString();
            double lengthofRightForeArm = Length(elbowright, wristright)*100;
            RightForeArmValue.Text = lengthofRightForeArm.ToString();
            double lengthofUpperSpine = Length(SpineShoulder, SpineMid)*100;
            UpperSpineValue.Text = lengthofUpperSpine.ToString();
            double lengthofLowerSpine = Length(SpineMid, SpineBase)*100;
            LowerSpineValue.Text = lengthofLowerSpine.ToString();
            double lengthofLeftThigh = Length(hipleft, kneeLeft)*100;
            LeftThighValue.Text = lengthofLeftThigh.ToString();
            double lengthofLeftLowerLeg = Length(kneeLeft, ankleleft)*100;
            LeftLowerLegValue.Text = lengthofLeftLowerLeg.ToString();
            double lengthofRightThigh = Length(hipright, kneeright);
            RightThighValue.Text = lengthofRightThigh.ToString();
            double lengthofRightLowerLeg = Length(kneeright, ankleright)*100;
            RightLowerLegValue.Text = lengthofRightLowerLeg.ToString();
            
            con.Open();
            SqlCommand cmdd = con.CreateCommand();
            cmdd.CommandType = CommandType.Text;
            cmdd.CommandText = "insert into BodyTracking (BodyTrackingID ,RecordDateTime,C_Height,C_Torso,C_Neck,C_LeftUpperArm,C_LeftForeArm,C_RightUpperArm,C_RightForeArm,C_UpperSpine,C_LowerSpine,C_LeftThigh,C_RightThigh,C_LeftLowerLeg,C_RightLowerLeg, C_LegLength) values('" + TrackingNo + "', '" + DateTime.Now + "', '" + HeightV + "', '" + LengthofTorso + "', '" + lengthofNeck + "', '" + lengthofLeftUpperArm + "', '" + lengthofLeftForeArm + "', '" + lengthofRightUpperArm + "', '" + lengthofRightForeArm + "', '" + lengthofUpperSpine + "', '" + lengthofLowerSpine + "', '" + lengthofLeftThigh + "', '" + lengthofRightThigh + "', '" + lengthofLeftLowerLeg + "', '" + lengthofRightLowerLeg + "', '" + LengthofLegsV + "')";
            cmdd.ExecuteNonQuery();
            con.Close();

            List<double> input = new List<double>();
            input.Add(HeightV);
            input.Add(LengthofTorso);
            input.Add(lengthofNeck);
            input.Add(lengthofLeftUpperArm);
            input.Add(lengthofLeftForeArm);
            input.Add(lengthofRightUpperArm);
            input.Add(lengthofRightForeArm);
            input.Add(lengthofUpperSpine);
            input.Add(lengthofLowerSpine);
            input.Add(lengthofLeftThigh);
            input.Add(lengthofLeftLowerLeg);
            input.Add(lengthofRightThigh);
            input.Add(lengthofRightLowerLeg);
            input.Add(LengthofLegsV);

            List<double> map = ExponentialWeightedAvg(input);          
        }

    }
}
