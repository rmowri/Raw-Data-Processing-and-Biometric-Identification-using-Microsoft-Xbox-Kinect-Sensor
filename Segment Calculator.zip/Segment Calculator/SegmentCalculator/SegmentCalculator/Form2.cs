﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SegmentCalculator
{
    public partial class Form2 : Form
    {
        public Image SelectedImage
        {
            get { return pb2.Image; }
        }
        public Form2(Bitmap i)
        {
            InitializeComponent();
            pb2.Image = i;
        }
    }
}
