﻿namespace SegmentCalculator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox12 = new System.Windows.Forms.GroupBox();
            this.label32 = new System.Windows.Forms.Label();
            this.LegLength = new System.Windows.Forms.TextBox();
            this.LeftLowerLegValue = new System.Windows.Forms.TextBox();
            this.RightThighValue = new System.Windows.Forms.TextBox();
            this.checkBox15 = new System.Windows.Forms.CheckBox();
            this.NeckValue = new System.Windows.Forms.TextBox();
            this.checkBox16 = new System.Windows.Forms.CheckBox();
            this.RightLowerLegValue = new System.Windows.Forms.TextBox();
            this.checkBox11 = new System.Windows.Forms.CheckBox();
            this.HeightValue = new System.Windows.Forms.TextBox();
            this.checkBox12 = new System.Windows.Forms.CheckBox();
            this.LeftThighValue = new System.Windows.Forms.TextBox();
            this.checkBox13 = new System.Windows.Forms.CheckBox();
            this.TorsoValue = new System.Windows.Forms.TextBox();
            this.checkBox14 = new System.Windows.Forms.CheckBox();
            this.LowerSpineValue = new System.Windows.Forms.TextBox();
            this.checkBox7 = new System.Windows.Forms.CheckBox();
            this.UpperSpineValue = new System.Windows.Forms.TextBox();
            this.checkBox8 = new System.Windows.Forms.CheckBox();
            this.LeftUpperArmValue = new System.Windows.Forms.TextBox();
            this.checkBox9 = new System.Windows.Forms.CheckBox();
            this.RightForeArmValue = new System.Windows.Forms.TextBox();
            this.checkBox10 = new System.Windows.Forms.CheckBox();
            this.LeftForeArmValue = new System.Windows.Forms.TextBox();
            this.checkBox5 = new System.Windows.Forms.CheckBox();
            this.RightUpperArmValue = new System.Windows.Forms.TextBox();
            this.checkBox6 = new System.Windows.Forms.CheckBox();
            this.checkBox3 = new System.Windows.Forms.CheckBox();
            this.checkBox4 = new System.Windows.Forms.CheckBox();
            this.pb = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.CFlabel = new System.Windows.Forms.Label();
            this.BFlabel = new System.Windows.Forms.Label();
            this.connect = new System.Windows.Forms.Button();
            this.CF = new System.Windows.Forms.Label();
            this.BF = new System.Windows.Forms.Label();
            this.modelPointsGroupBox = new System.Windows.Forms.GroupBox();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.trackingID = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.KneeRightZ = new System.Windows.Forms.TextBox();
            this.KneeRightY = new System.Windows.Forms.TextBox();
            this.KneeRightX = new System.Windows.Forms.TextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.ShoulderRightZ = new System.Windows.Forms.TextBox();
            this.ShoulderRightY = new System.Windows.Forms.TextBox();
            this.ShoulderRightX = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.ThumbRightZ = new System.Windows.Forms.TextBox();
            this.ThumbRightY = new System.Windows.Forms.TextBox();
            this.ThumbRightX = new System.Windows.Forms.TextBox();
            this.ThumbLeftZ = new System.Windows.Forms.TextBox();
            this.ThumbLeftY = new System.Windows.Forms.TextBox();
            this.ThumbLeftX = new System.Windows.Forms.TextBox();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.SpineShoulderZ = new System.Windows.Forms.TextBox();
            this.SpineShoulderY = new System.Windows.Forms.TextBox();
            this.SpineShoulderX = new System.Windows.Forms.TextBox();
            this.FootRightZ = new System.Windows.Forms.TextBox();
            this.FootRightY = new System.Windows.Forms.TextBox();
            this.FootRightX = new System.Windows.Forms.TextBox();
            this.AnkleRightZ = new System.Windows.Forms.TextBox();
            this.AnkleRightY = new System.Windows.Forms.TextBox();
            this.AnkleRightX = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.HipRightZ = new System.Windows.Forms.TextBox();
            this.HipRightY = new System.Windows.Forms.TextBox();
            this.HipRightX = new System.Windows.Forms.TextBox();
            this.FootLeftZ = new System.Windows.Forms.TextBox();
            this.FootLeftY = new System.Windows.Forms.TextBox();
            this.FootLeftX = new System.Windows.Forms.TextBox();
            this.AnkleLeftZ = new System.Windows.Forms.TextBox();
            this.AnkleLeftY = new System.Windows.Forms.TextBox();
            this.AnkleLeftX = new System.Windows.Forms.TextBox();
            this.KneeLeftZ = new System.Windows.Forms.TextBox();
            this.KneeLeftY = new System.Windows.Forms.TextBox();
            this.KneeLeftX = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.HipLeftZ = new System.Windows.Forms.TextBox();
            this.HipLeftY = new System.Windows.Forms.TextBox();
            this.HipLeftX = new System.Windows.Forms.TextBox();
            this.HandTipRightZ = new System.Windows.Forms.TextBox();
            this.HandTipRightY = new System.Windows.Forms.TextBox();
            this.HandTipRightX = new System.Windows.Forms.TextBox();
            this.WristRightZ = new System.Windows.Forms.TextBox();
            this.WristRightY = new System.Windows.Forms.TextBox();
            this.WristRightX = new System.Windows.Forms.TextBox();
            this.ElbowRightZ = new System.Windows.Forms.TextBox();
            this.ElbowRightY = new System.Windows.Forms.TextBox();
            this.ElbowRightX = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.HandTipLeftZ = new System.Windows.Forms.TextBox();
            this.HandTipLeftY = new System.Windows.Forms.TextBox();
            this.HandTipLeftX = new System.Windows.Forms.TextBox();
            this.WristLeftZ = new System.Windows.Forms.TextBox();
            this.WristLeftY = new System.Windows.Forms.TextBox();
            this.WristLeftX = new System.Windows.Forms.TextBox();
            this.ElbowLeftZ = new System.Windows.Forms.TextBox();
            this.ElbowLeftY = new System.Windows.Forms.TextBox();
            this.ElbowLeftX = new System.Windows.Forms.TextBox();
            this.ShoulderLeftZ = new System.Windows.Forms.TextBox();
            this.ShoulderLeftY = new System.Windows.Forms.TextBox();
            this.ShoulderLeftX = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.HeadZ = new System.Windows.Forms.TextBox();
            this.HeadY = new System.Windows.Forms.TextBox();
            this.HeadX = new System.Windows.Forms.TextBox();
            this.NeckZ = new System.Windows.Forms.TextBox();
            this.NeckY = new System.Windows.Forms.TextBox();
            this.NeckX = new System.Windows.Forms.TextBox();
            this.SpineMidZ = new System.Windows.Forms.TextBox();
            this.SpineMidY = new System.Windows.Forms.TextBox();
            this.SpineMidX = new System.Windows.Forms.TextBox();
            this.SpineBaseZ = new System.Windows.Forms.TextBox();
            this.SpineBaseY = new System.Windows.Forms.TextBox();
            this.SpineBaseX = new System.Windows.Forms.TextBox();
            this.modelPoint4Label = new System.Windows.Forms.Label();
            this.modelPoint1Label = new System.Windows.Forms.Label();
            this.modelPoint3Label = new System.Windows.Forms.Label();
            this.modelPoint2Label = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.pCount = new System.Windows.Forms.Label();
            this.P6 = new System.Windows.Forms.TextBox();
            this.P6ID = new System.Windows.Forms.TextBox();
            this.P5 = new System.Windows.Forms.TextBox();
            this.P5ID = new System.Windows.Forms.TextBox();
            this.P4 = new System.Windows.Forms.TextBox();
            this.P4ID = new System.Windows.Forms.TextBox();
            this.P3 = new System.Windows.Forms.TextBox();
            this.P3ID = new System.Windows.Forms.TextBox();
            this.P2 = new System.Windows.Forms.TextBox();
            this.P2ID = new System.Windows.Forms.TextBox();
            this.label27 = new System.Windows.Forms.Label();
            this.P1 = new System.Windows.Forms.TextBox();
            this.label28 = new System.Windows.Forms.Label();
            this.P1ID = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.BE = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox12.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).BeginInit();
            this.modelPointsGroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox12
            // 
            this.groupBox12.Controls.Add(this.label32);
            this.groupBox12.Controls.Add(this.LegLength);
            this.groupBox12.Controls.Add(this.LeftLowerLegValue);
            this.groupBox12.Controls.Add(this.RightThighValue);
            this.groupBox12.Controls.Add(this.checkBox15);
            this.groupBox12.Controls.Add(this.NeckValue);
            this.groupBox12.Controls.Add(this.checkBox16);
            this.groupBox12.Controls.Add(this.RightLowerLegValue);
            this.groupBox12.Controls.Add(this.checkBox11);
            this.groupBox12.Controls.Add(this.HeightValue);
            this.groupBox12.Controls.Add(this.checkBox12);
            this.groupBox12.Controls.Add(this.LeftThighValue);
            this.groupBox12.Controls.Add(this.checkBox13);
            this.groupBox12.Controls.Add(this.TorsoValue);
            this.groupBox12.Controls.Add(this.checkBox14);
            this.groupBox12.Controls.Add(this.LowerSpineValue);
            this.groupBox12.Controls.Add(this.checkBox7);
            this.groupBox12.Controls.Add(this.UpperSpineValue);
            this.groupBox12.Controls.Add(this.checkBox8);
            this.groupBox12.Controls.Add(this.LeftUpperArmValue);
            this.groupBox12.Controls.Add(this.checkBox9);
            this.groupBox12.Controls.Add(this.RightForeArmValue);
            this.groupBox12.Controls.Add(this.checkBox10);
            this.groupBox12.Controls.Add(this.LeftForeArmValue);
            this.groupBox12.Controls.Add(this.checkBox5);
            this.groupBox12.Controls.Add(this.RightUpperArmValue);
            this.groupBox12.Controls.Add(this.checkBox6);
            this.groupBox12.Controls.Add(this.checkBox3);
            this.groupBox12.Controls.Add(this.checkBox4);
            this.groupBox12.Location = new System.Drawing.Point(12, 40);
            this.groupBox12.Name = "groupBox12";
            this.groupBox12.Size = new System.Drawing.Size(317, 497);
            this.groupBox12.TabIndex = 77;
            this.groupBox12.TabStop = false;
            this.groupBox12.Text = "Anthromorphic Data";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(151, 25);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(85, 13);
            this.label32.TabIndex = 110;
            this.label32.Text = "Segment Length";
            // 
            // LegLength
            // 
            this.LegLength.Location = new System.Drawing.Point(125, 465);
            this.LegLength.Name = "LegLength";
            this.LegLength.Size = new System.Drawing.Size(156, 20);
            this.LegLength.TabIndex = 94;
            // 
            // LeftLowerLegValue
            // 
            this.LeftLowerLegValue.Location = new System.Drawing.Point(125, 398);
            this.LeftLowerLegValue.Name = "LeftLowerLegValue";
            this.LeftLowerLegValue.Size = new System.Drawing.Size(156, 20);
            this.LeftLowerLegValue.TabIndex = 93;
            // 
            // RightThighValue
            // 
            this.RightThighValue.Location = new System.Drawing.Point(125, 360);
            this.RightThighValue.Name = "RightThighValue";
            this.RightThighValue.Size = new System.Drawing.Size(156, 20);
            this.RightThighValue.TabIndex = 92;
            // 
            // checkBox15
            // 
            this.checkBox15.AutoSize = true;
            this.checkBox15.Location = new System.Drawing.Point(12, 468);
            this.checkBox15.Name = "checkBox15";
            this.checkBox15.Size = new System.Drawing.Size(80, 17);
            this.checkBox15.TabIndex = 91;
            this.checkBox15.Text = "Leg Length";
            this.checkBox15.UseVisualStyleBackColor = true;
            // 
            // NeckValue
            // 
            this.NeckValue.Location = new System.Drawing.Point(125, 111);
            this.NeckValue.Name = "NeckValue";
            this.NeckValue.Size = new System.Drawing.Size(156, 20);
            this.NeckValue.TabIndex = 59;
            // 
            // checkBox16
            // 
            this.checkBox16.AutoSize = true;
            this.checkBox16.Location = new System.Drawing.Point(12, 113);
            this.checkBox16.Name = "checkBox16";
            this.checkBox16.Size = new System.Drawing.Size(52, 17);
            this.checkBox16.TabIndex = 90;
            this.checkBox16.Text = "Neck";
            this.checkBox16.UseVisualStyleBackColor = true;
            // 
            // RightLowerLegValue
            // 
            this.RightLowerLegValue.Location = new System.Drawing.Point(125, 436);
            this.RightLowerLegValue.Name = "RightLowerLegValue";
            this.RightLowerLegValue.Size = new System.Drawing.Size(156, 20);
            this.RightLowerLegValue.TabIndex = 75;
            // 
            // checkBox11
            // 
            this.checkBox11.AutoSize = true;
            this.checkBox11.Location = new System.Drawing.Point(12, 436);
            this.checkBox11.Name = "checkBox11";
            this.checkBox11.Size = new System.Drawing.Size(104, 17);
            this.checkBox11.TabIndex = 88;
            this.checkBox11.Text = "Right Lower Leg";
            this.checkBox11.UseVisualStyleBackColor = true;
            // 
            // HeightValue
            // 
            this.HeightValue.Location = new System.Drawing.Point(125, 53);
            this.HeightValue.Name = "HeightValue";
            this.HeightValue.Size = new System.Drawing.Size(156, 20);
            this.HeightValue.TabIndex = 55;
            // 
            // checkBox12
            // 
            this.checkBox12.AutoSize = true;
            this.checkBox12.Location = new System.Drawing.Point(12, 398);
            this.checkBox12.Name = "checkBox12";
            this.checkBox12.Size = new System.Drawing.Size(97, 17);
            this.checkBox12.TabIndex = 87;
            this.checkBox12.Text = "Left Lower Leg";
            this.checkBox12.UseVisualStyleBackColor = true;
            // 
            // LeftThighValue
            // 
            this.LeftThighValue.Location = new System.Drawing.Point(125, 323);
            this.LeftThighValue.Name = "LeftThighValue";
            this.LeftThighValue.Size = new System.Drawing.Size(156, 20);
            this.LeftThighValue.TabIndex = 73;
            // 
            // checkBox13
            // 
            this.checkBox13.AutoSize = true;
            this.checkBox13.Location = new System.Drawing.Point(12, 360);
            this.checkBox13.Name = "checkBox13";
            this.checkBox13.Size = new System.Drawing.Size(81, 17);
            this.checkBox13.TabIndex = 86;
            this.checkBox13.Text = "Right Thigh";
            this.checkBox13.UseVisualStyleBackColor = true;
            // 
            // TorsoValue
            // 
            this.TorsoValue.Location = new System.Drawing.Point(125, 82);
            this.TorsoValue.Name = "TorsoValue";
            this.TorsoValue.Size = new System.Drawing.Size(156, 20);
            this.TorsoValue.TabIndex = 57;
            // 
            // checkBox14
            // 
            this.checkBox14.AutoSize = true;
            this.checkBox14.Location = new System.Drawing.Point(12, 326);
            this.checkBox14.Name = "checkBox14";
            this.checkBox14.Size = new System.Drawing.Size(74, 17);
            this.checkBox14.TabIndex = 85;
            this.checkBox14.Text = "Left Thigh";
            this.checkBox14.UseVisualStyleBackColor = true;
            // 
            // LowerSpineValue
            // 
            this.LowerSpineValue.Location = new System.Drawing.Point(125, 292);
            this.LowerSpineValue.Name = "LowerSpineValue";
            this.LowerSpineValue.Size = new System.Drawing.Size(156, 20);
            this.LowerSpineValue.TabIndex = 71;
            // 
            // checkBox7
            // 
            this.checkBox7.AutoSize = true;
            this.checkBox7.Location = new System.Drawing.Point(12, 295);
            this.checkBox7.Name = "checkBox7";
            this.checkBox7.Size = new System.Drawing.Size(85, 17);
            this.checkBox7.TabIndex = 84;
            this.checkBox7.Text = "Lower Spine";
            this.checkBox7.UseVisualStyleBackColor = true;
            // 
            // UpperSpineValue
            // 
            this.UpperSpineValue.Location = new System.Drawing.Point(125, 264);
            this.UpperSpineValue.Name = "UpperSpineValue";
            this.UpperSpineValue.Size = new System.Drawing.Size(156, 20);
            this.UpperSpineValue.TabIndex = 69;
            // 
            // checkBox8
            // 
            this.checkBox8.AutoSize = true;
            this.checkBox8.Location = new System.Drawing.Point(12, 263);
            this.checkBox8.Name = "checkBox8";
            this.checkBox8.Size = new System.Drawing.Size(85, 17);
            this.checkBox8.TabIndex = 83;
            this.checkBox8.Text = "Upper Spine";
            this.checkBox8.UseVisualStyleBackColor = true;
            // 
            // LeftUpperArmValue
            // 
            this.LeftUpperArmValue.Location = new System.Drawing.Point(125, 140);
            this.LeftUpperArmValue.Name = "LeftUpperArmValue";
            this.LeftUpperArmValue.Size = new System.Drawing.Size(156, 20);
            this.LeftUpperArmValue.TabIndex = 61;
            // 
            // checkBox9
            // 
            this.checkBox9.AutoSize = true;
            this.checkBox9.Location = new System.Drawing.Point(12, 233);
            this.checkBox9.Name = "checkBox9";
            this.checkBox9.Size = new System.Drawing.Size(93, 17);
            this.checkBox9.TabIndex = 82;
            this.checkBox9.Text = "Right ForeArm";
            this.checkBox9.UseVisualStyleBackColor = true;
            // 
            // RightForeArmValue
            // 
            this.RightForeArmValue.Location = new System.Drawing.Point(125, 234);
            this.RightForeArmValue.Name = "RightForeArmValue";
            this.RightForeArmValue.Size = new System.Drawing.Size(156, 20);
            this.RightForeArmValue.TabIndex = 67;
            // 
            // checkBox10
            // 
            this.checkBox10.AutoSize = true;
            this.checkBox10.Location = new System.Drawing.Point(12, 168);
            this.checkBox10.Name = "checkBox10";
            this.checkBox10.Size = new System.Drawing.Size(86, 17);
            this.checkBox10.TabIndex = 81;
            this.checkBox10.Text = "Left ForeArm";
            this.checkBox10.UseVisualStyleBackColor = true;
            // 
            // LeftForeArmValue
            // 
            this.LeftForeArmValue.Location = new System.Drawing.Point(125, 168);
            this.LeftForeArmValue.Name = "LeftForeArmValue";
            this.LeftForeArmValue.Size = new System.Drawing.Size(156, 20);
            this.LeftForeArmValue.TabIndex = 63;
            // 
            // checkBox5
            // 
            this.checkBox5.AutoSize = true;
            this.checkBox5.Location = new System.Drawing.Point(12, 197);
            this.checkBox5.Name = "checkBox5";
            this.checkBox5.Size = new System.Drawing.Size(104, 17);
            this.checkBox5.TabIndex = 80;
            this.checkBox5.Text = "Right Upper Arm";
            this.checkBox5.UseVisualStyleBackColor = true;
            // 
            // RightUpperArmValue
            // 
            this.RightUpperArmValue.Location = new System.Drawing.Point(125, 197);
            this.RightUpperArmValue.Name = "RightUpperArmValue";
            this.RightUpperArmValue.Size = new System.Drawing.Size(156, 20);
            this.RightUpperArmValue.TabIndex = 65;
            // 
            // checkBox6
            // 
            this.checkBox6.AutoSize = true;
            this.checkBox6.Location = new System.Drawing.Point(12, 139);
            this.checkBox6.Name = "checkBox6";
            this.checkBox6.Size = new System.Drawing.Size(97, 17);
            this.checkBox6.TabIndex = 79;
            this.checkBox6.Text = "Left Upper Arm";
            this.checkBox6.UseVisualStyleBackColor = true;
            // 
            // checkBox3
            // 
            this.checkBox3.AutoSize = true;
            this.checkBox3.Location = new System.Drawing.Point(12, 55);
            this.checkBox3.Name = "checkBox3";
            this.checkBox3.Size = new System.Drawing.Size(57, 17);
            this.checkBox3.TabIndex = 77;
            this.checkBox3.Text = "Height";
            this.checkBox3.UseVisualStyleBackColor = true;
            // 
            // checkBox4
            // 
            this.checkBox4.AutoSize = true;
            this.checkBox4.Location = new System.Drawing.Point(12, 85);
            this.checkBox4.Name = "checkBox4";
            this.checkBox4.Size = new System.Drawing.Size(53, 17);
            this.checkBox4.TabIndex = 78;
            this.checkBox4.Text = "Torso";
            this.checkBox4.UseVisualStyleBackColor = true;
            // 
            // pb
            // 
            this.pb.Location = new System.Drawing.Point(335, 47);
            this.pb.Name = "pb";
            this.pb.Size = new System.Drawing.Size(646, 490);
            this.pb.TabIndex = 78;
            this.pb.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("MS Reference Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(702, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(85, 26);
            this.label1.TabIndex = 79;
            this.label1.Text = "VIDEO";
            // 
            // CFlabel
            // 
            this.CFlabel.AutoSize = true;
            this.CFlabel.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CFlabel.Location = new System.Drawing.Point(186, 554);
            this.CFlabel.Name = "CFlabel";
            this.CFlabel.Size = new System.Drawing.Size(248, 24);
            this.CFlabel.TabIndex = 80;
            this.CFlabel.Text = "Color Frame Numbers:";
            // 
            // BFlabel
            // 
            this.BFlabel.AutoSize = true;
            this.BFlabel.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BFlabel.Location = new System.Drawing.Point(518, 554);
            this.BFlabel.Name = "BFlabel";
            this.BFlabel.Size = new System.Drawing.Size(244, 24);
            this.BFlabel.TabIndex = 81;
            this.BFlabel.Text = "Body Frame Numbers:";
            // 
            // connect
            // 
            this.connect.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.connect.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.connect.Location = new System.Drawing.Point(12, 542);
            this.connect.Name = "connect";
            this.connect.Size = new System.Drawing.Size(158, 49);
            this.connect.TabIndex = 82;
            this.connect.Text = "CONNECT";
            this.connect.UseVisualStyleBackColor = false;
            this.connect.Click += new System.EventHandler(this.button1_Click);
            // 
            // CF
            // 
            this.CF.AutoSize = true;
            this.CF.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CF.Location = new System.Drawing.Point(442, 554);
            this.CF.Name = "CF";
            this.CF.Size = new System.Drawing.Size(23, 24);
            this.CF.TabIndex = 83;
            this.CF.Text = "0";
            // 
            // BF
            // 
            this.BF.AutoSize = true;
            this.BF.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BF.Location = new System.Drawing.Point(781, 554);
            this.BF.Name = "BF";
            this.BF.Size = new System.Drawing.Size(23, 24);
            this.BF.TabIndex = 84;
            this.BF.Text = "0";
            // 
            // modelPointsGroupBox
            // 
            this.modelPointsGroupBox.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.modelPointsGroupBox.Controls.Add(this.label34);
            this.modelPointsGroupBox.Controls.Add(this.label33);
            this.modelPointsGroupBox.Controls.Add(this.label30);
            this.modelPointsGroupBox.Controls.Add(this.trackingID);
            this.modelPointsGroupBox.Controls.Add(this.label29);
            this.modelPointsGroupBox.Controls.Add(this.KneeRightZ);
            this.modelPointsGroupBox.Controls.Add(this.KneeRightY);
            this.modelPointsGroupBox.Controls.Add(this.KneeRightX);
            this.modelPointsGroupBox.Controls.Add(this.label26);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderRightZ);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderRightY);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderRightX);
            this.modelPointsGroupBox.Controls.Add(this.label25);
            this.modelPointsGroupBox.Controls.Add(this.ThumbRightZ);
            this.modelPointsGroupBox.Controls.Add(this.ThumbRightY);
            this.modelPointsGroupBox.Controls.Add(this.ThumbRightX);
            this.modelPointsGroupBox.Controls.Add(this.ThumbLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.ThumbLeftY);
            this.modelPointsGroupBox.Controls.Add(this.ThumbLeftX);
            this.modelPointsGroupBox.Controls.Add(this.label18);
            this.modelPointsGroupBox.Controls.Add(this.label19);
            this.modelPointsGroupBox.Controls.Add(this.SpineShoulderZ);
            this.modelPointsGroupBox.Controls.Add(this.SpineShoulderY);
            this.modelPointsGroupBox.Controls.Add(this.SpineShoulderX);
            this.modelPointsGroupBox.Controls.Add(this.FootRightZ);
            this.modelPointsGroupBox.Controls.Add(this.FootRightY);
            this.modelPointsGroupBox.Controls.Add(this.FootRightX);
            this.modelPointsGroupBox.Controls.Add(this.AnkleRightZ);
            this.modelPointsGroupBox.Controls.Add(this.AnkleRightY);
            this.modelPointsGroupBox.Controls.Add(this.AnkleRightX);
            this.modelPointsGroupBox.Controls.Add(this.label22);
            this.modelPointsGroupBox.Controls.Add(this.label23);
            this.modelPointsGroupBox.Controls.Add(this.label24);
            this.modelPointsGroupBox.Controls.Add(this.HipRightZ);
            this.modelPointsGroupBox.Controls.Add(this.HipRightY);
            this.modelPointsGroupBox.Controls.Add(this.HipRightX);
            this.modelPointsGroupBox.Controls.Add(this.FootLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.FootLeftY);
            this.modelPointsGroupBox.Controls.Add(this.FootLeftX);
            this.modelPointsGroupBox.Controls.Add(this.AnkleLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.AnkleLeftY);
            this.modelPointsGroupBox.Controls.Add(this.AnkleLeftX);
            this.modelPointsGroupBox.Controls.Add(this.KneeLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.KneeLeftY);
            this.modelPointsGroupBox.Controls.Add(this.KneeLeftX);
            this.modelPointsGroupBox.Controls.Add(this.label9);
            this.modelPointsGroupBox.Controls.Add(this.label10);
            this.modelPointsGroupBox.Controls.Add(this.label11);
            this.modelPointsGroupBox.Controls.Add(this.label12);
            this.modelPointsGroupBox.Controls.Add(this.HipLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.HipLeftY);
            this.modelPointsGroupBox.Controls.Add(this.HipLeftX);
            this.modelPointsGroupBox.Controls.Add(this.HandTipRightZ);
            this.modelPointsGroupBox.Controls.Add(this.HandTipRightY);
            this.modelPointsGroupBox.Controls.Add(this.HandTipRightX);
            this.modelPointsGroupBox.Controls.Add(this.WristRightZ);
            this.modelPointsGroupBox.Controls.Add(this.WristRightY);
            this.modelPointsGroupBox.Controls.Add(this.WristRightX);
            this.modelPointsGroupBox.Controls.Add(this.ElbowRightZ);
            this.modelPointsGroupBox.Controls.Add(this.ElbowRightY);
            this.modelPointsGroupBox.Controls.Add(this.ElbowRightX);
            this.modelPointsGroupBox.Controls.Add(this.label13);
            this.modelPointsGroupBox.Controls.Add(this.label14);
            this.modelPointsGroupBox.Controls.Add(this.label15);
            this.modelPointsGroupBox.Controls.Add(this.label16);
            this.modelPointsGroupBox.Controls.Add(this.HandTipLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.HandTipLeftY);
            this.modelPointsGroupBox.Controls.Add(this.HandTipLeftX);
            this.modelPointsGroupBox.Controls.Add(this.WristLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.WristLeftY);
            this.modelPointsGroupBox.Controls.Add(this.WristLeftX);
            this.modelPointsGroupBox.Controls.Add(this.ElbowLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.ElbowLeftY);
            this.modelPointsGroupBox.Controls.Add(this.ElbowLeftX);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderLeftZ);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderLeftY);
            this.modelPointsGroupBox.Controls.Add(this.ShoulderLeftX);
            this.modelPointsGroupBox.Controls.Add(this.label5);
            this.modelPointsGroupBox.Controls.Add(this.label6);
            this.modelPointsGroupBox.Controls.Add(this.label7);
            this.modelPointsGroupBox.Controls.Add(this.label8);
            this.modelPointsGroupBox.Controls.Add(this.HeadZ);
            this.modelPointsGroupBox.Controls.Add(this.HeadY);
            this.modelPointsGroupBox.Controls.Add(this.HeadX);
            this.modelPointsGroupBox.Controls.Add(this.NeckZ);
            this.modelPointsGroupBox.Controls.Add(this.NeckY);
            this.modelPointsGroupBox.Controls.Add(this.NeckX);
            this.modelPointsGroupBox.Controls.Add(this.SpineMidZ);
            this.modelPointsGroupBox.Controls.Add(this.SpineMidY);
            this.modelPointsGroupBox.Controls.Add(this.SpineMidX);
            this.modelPointsGroupBox.Controls.Add(this.SpineBaseZ);
            this.modelPointsGroupBox.Controls.Add(this.SpineBaseY);
            this.modelPointsGroupBox.Controls.Add(this.SpineBaseX);
            this.modelPointsGroupBox.Controls.Add(this.modelPoint4Label);
            this.modelPointsGroupBox.Controls.Add(this.modelPoint1Label);
            this.modelPointsGroupBox.Controls.Add(this.modelPoint3Label);
            this.modelPointsGroupBox.Controls.Add(this.modelPoint2Label);
            this.modelPointsGroupBox.Location = new System.Drawing.Point(987, 9);
            this.modelPointsGroupBox.Name = "modelPointsGroupBox";
            this.modelPointsGroupBox.Size = new System.Drawing.Size(371, 661);
            this.modelPointsGroupBox.TabIndex = 85;
            this.modelPointsGroupBox.TabStop = false;
            this.modelPointsGroupBox.Text = "Model Coordinates ";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.Location = new System.Drawing.Point(234, 56);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(15, 13);
            this.label34.TabIndex = 130;
            this.label34.Text = "Y";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(303, 56);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(15, 13);
            this.label33.TabIndex = 129;
            this.label33.Text = "Z";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(170, 56);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(15, 13);
            this.label30.TabIndex = 128;
            this.label30.Text = "X";
            // 
            // trackingID
            // 
            this.trackingID.Location = new System.Drawing.Point(173, 26);
            this.trackingID.Name = "trackingID";
            this.trackingID.Size = new System.Drawing.Size(123, 20);
            this.trackingID.TabIndex = 113;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(20, 27);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(132, 16);
            this.label29.TabIndex = 112;
            this.label29.Text = "Body Tracking ID:";
            // 
            // KneeRightZ
            // 
            this.KneeRightZ.Location = new System.Drawing.Point(283, 501);
            this.KneeRightZ.Name = "KneeRightZ";
            this.KneeRightZ.Size = new System.Drawing.Size(60, 20);
            this.KneeRightZ.TabIndex = 103;
            this.KneeRightZ.Tag = "32";
            // 
            // KneeRightY
            // 
            this.KneeRightY.Location = new System.Drawing.Point(217, 501);
            this.KneeRightY.Name = "KneeRightY";
            this.KneeRightY.Size = new System.Drawing.Size(60, 20);
            this.KneeRightY.TabIndex = 102;
            this.KneeRightY.Tag = "31";
            // 
            // KneeRightX
            // 
            this.KneeRightX.Location = new System.Drawing.Point(152, 502);
            this.KneeRightX.Name = "KneeRightX";
            this.KneeRightX.Size = new System.Drawing.Size(60, 20);
            this.KneeRightX.TabIndex = 101;
            this.KneeRightX.Tag = "30";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.Location = new System.Drawing.Point(14, 504);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(101, 13);
            this.label26.TabIndex = 100;
            this.label26.Text = "KNEERIGHT 18:";
            // 
            // ShoulderRightZ
            // 
            this.ShoulderRightZ.Location = new System.Drawing.Point(282, 278);
            this.ShoulderRightZ.Name = "ShoulderRightZ";
            this.ShoulderRightZ.Size = new System.Drawing.Size(60, 20);
            this.ShoulderRightZ.TabIndex = 99;
            this.ShoulderRightZ.Tag = "32";
            // 
            // ShoulderRightY
            // 
            this.ShoulderRightY.Location = new System.Drawing.Point(217, 278);
            this.ShoulderRightY.Name = "ShoulderRightY";
            this.ShoulderRightY.Size = new System.Drawing.Size(60, 20);
            this.ShoulderRightY.TabIndex = 98;
            this.ShoulderRightY.Tag = "31";
            // 
            // ShoulderRightX
            // 
            this.ShoulderRightX.Location = new System.Drawing.Point(152, 278);
            this.ShoulderRightX.Name = "ShoulderRightX";
            this.ShoulderRightX.Size = new System.Drawing.Size(60, 20);
            this.ShoulderRightX.TabIndex = 97;
            this.ShoulderRightX.Tag = "30";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.Location = new System.Drawing.Point(14, 278);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(129, 13);
            this.label25.TabIndex = 96;
            this.label25.Text = "SHOULDERRIGHT 9:";
            // 
            // ThumbRightZ
            // 
            this.ThumbRightZ.Location = new System.Drawing.Point(282, 628);
            this.ThumbRightZ.Name = "ThumbRightZ";
            this.ThumbRightZ.Size = new System.Drawing.Size(60, 20);
            this.ThumbRightZ.TabIndex = 91;
            this.ThumbRightZ.Tag = "22";
            // 
            // ThumbRightY
            // 
            this.ThumbRightY.Location = new System.Drawing.Point(217, 628);
            this.ThumbRightY.Name = "ThumbRightY";
            this.ThumbRightY.Size = new System.Drawing.Size(60, 20);
            this.ThumbRightY.TabIndex = 90;
            this.ThumbRightY.Tag = "21";
            // 
            // ThumbRightX
            // 
            this.ThumbRightX.Location = new System.Drawing.Point(152, 628);
            this.ThumbRightX.Name = "ThumbRightX";
            this.ThumbRightX.Size = new System.Drawing.Size(60, 20);
            this.ThumbRightX.TabIndex = 89;
            this.ThumbRightX.Tag = "20";
            // 
            // ThumbLeftZ
            // 
            this.ThumbLeftZ.Location = new System.Drawing.Point(282, 602);
            this.ThumbLeftZ.Name = "ThumbLeftZ";
            this.ThumbLeftZ.Size = new System.Drawing.Size(60, 20);
            this.ThumbLeftZ.TabIndex = 83;
            this.ThumbLeftZ.Tag = "2";
            // 
            // ThumbLeftY
            // 
            this.ThumbLeftY.Location = new System.Drawing.Point(217, 602);
            this.ThumbLeftY.Name = "ThumbLeftY";
            this.ThumbLeftY.Size = new System.Drawing.Size(60, 20);
            this.ThumbLeftY.TabIndex = 82;
            this.ThumbLeftY.Tag = "1";
            // 
            // ThumbLeftX
            // 
            this.ThumbLeftX.Location = new System.Drawing.Point(152, 602);
            this.ThumbLeftX.Name = "ThumbLeftX";
            this.ThumbLeftX.Size = new System.Drawing.Size(60, 20);
            this.ThumbLeftX.TabIndex = 81;
            this.ThumbLeftX.Tag = "0";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.Location = new System.Drawing.Point(17, 605);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(103, 13);
            this.label18.TabIndex = 80;
            this.label18.Text = "THUMBLEFT 22:";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.Location = new System.Drawing.Point(17, 631);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(112, 13);
            this.label19.TabIndex = 88;
            this.label19.Text = "THUMBRIGHT 25:";
            // 
            // SpineShoulderZ
            // 
            this.SpineShoulderZ.Location = new System.Drawing.Point(281, 576);
            this.SpineShoulderZ.Name = "SpineShoulderZ";
            this.SpineShoulderZ.Size = new System.Drawing.Size(60, 20);
            this.SpineShoulderZ.TabIndex = 75;
            this.SpineShoulderZ.Tag = "22";
            // 
            // SpineShoulderY
            // 
            this.SpineShoulderY.Location = new System.Drawing.Point(216, 576);
            this.SpineShoulderY.Name = "SpineShoulderY";
            this.SpineShoulderY.Size = new System.Drawing.Size(60, 20);
            this.SpineShoulderY.TabIndex = 74;
            this.SpineShoulderY.Tag = "21";
            // 
            // SpineShoulderX
            // 
            this.SpineShoulderX.Location = new System.Drawing.Point(151, 576);
            this.SpineShoulderX.Name = "SpineShoulderX";
            this.SpineShoulderX.Size = new System.Drawing.Size(60, 20);
            this.SpineShoulderX.TabIndex = 73;
            this.SpineShoulderX.Tag = "20";
            // 
            // FootRightZ
            // 
            this.FootRightZ.Location = new System.Drawing.Point(281, 551);
            this.FootRightZ.Name = "FootRightZ";
            this.FootRightZ.Size = new System.Drawing.Size(60, 20);
            this.FootRightZ.TabIndex = 71;
            this.FootRightZ.Tag = "12";
            // 
            // FootRightY
            // 
            this.FootRightY.Location = new System.Drawing.Point(216, 551);
            this.FootRightY.Name = "FootRightY";
            this.FootRightY.Size = new System.Drawing.Size(60, 20);
            this.FootRightY.TabIndex = 70;
            this.FootRightY.Tag = "11";
            // 
            // FootRightX
            // 
            this.FootRightX.Location = new System.Drawing.Point(151, 551);
            this.FootRightX.Name = "FootRightX";
            this.FootRightX.Size = new System.Drawing.Size(60, 20);
            this.FootRightX.TabIndex = 69;
            this.FootRightX.Tag = "10";
            // 
            // AnkleRightZ
            // 
            this.AnkleRightZ.Location = new System.Drawing.Point(281, 526);
            this.AnkleRightZ.Name = "AnkleRightZ";
            this.AnkleRightZ.Size = new System.Drawing.Size(60, 20);
            this.AnkleRightZ.TabIndex = 67;
            this.AnkleRightZ.Tag = "2";
            // 
            // AnkleRightY
            // 
            this.AnkleRightY.Location = new System.Drawing.Point(216, 526);
            this.AnkleRightY.Name = "AnkleRightY";
            this.AnkleRightY.Size = new System.Drawing.Size(60, 20);
            this.AnkleRightY.TabIndex = 66;
            this.AnkleRightY.Tag = "1";
            // 
            // AnkleRightX
            // 
            this.AnkleRightX.Location = new System.Drawing.Point(151, 526);
            this.AnkleRightX.Name = "AnkleRightX";
            this.AnkleRightX.Size = new System.Drawing.Size(60, 20);
            this.AnkleRightX.TabIndex = 65;
            this.AnkleRightX.Tag = "0";
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.Location = new System.Drawing.Point(16, 529);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(108, 13);
            this.label22.TabIndex = 64;
            this.label22.Text = "ANKLERIGHT 19:";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.Location = new System.Drawing.Point(16, 579);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(134, 13);
            this.label23.TabIndex = 72;
            this.label23.Text = "SPINESHOULDER 21:";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.Location = new System.Drawing.Point(16, 554);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(101, 13);
            this.label24.TabIndex = 68;
            this.label24.Text = "FOOTRIGHT 20:";
            // 
            // HipRightZ
            // 
            this.HipRightZ.Location = new System.Drawing.Point(283, 475);
            this.HipRightZ.Name = "HipRightZ";
            this.HipRightZ.Size = new System.Drawing.Size(60, 20);
            this.HipRightZ.TabIndex = 63;
            this.HipRightZ.Tag = "32";
            // 
            // HipRightY
            // 
            this.HipRightY.Location = new System.Drawing.Point(217, 475);
            this.HipRightY.Name = "HipRightY";
            this.HipRightY.Size = new System.Drawing.Size(60, 20);
            this.HipRightY.TabIndex = 62;
            this.HipRightY.Tag = "31";
            // 
            // HipRightX
            // 
            this.HipRightX.Location = new System.Drawing.Point(152, 476);
            this.HipRightX.Name = "HipRightX";
            this.HipRightX.Size = new System.Drawing.Size(60, 20);
            this.HipRightX.TabIndex = 61;
            this.HipRightX.Tag = "30";
            // 
            // FootLeftZ
            // 
            this.FootLeftZ.Location = new System.Drawing.Point(282, 450);
            this.FootLeftZ.Name = "FootLeftZ";
            this.FootLeftZ.Size = new System.Drawing.Size(60, 20);
            this.FootLeftZ.TabIndex = 59;
            this.FootLeftZ.Tag = "22";
            // 
            // FootLeftY
            // 
            this.FootLeftY.Location = new System.Drawing.Point(217, 450);
            this.FootLeftY.Name = "FootLeftY";
            this.FootLeftY.Size = new System.Drawing.Size(60, 20);
            this.FootLeftY.TabIndex = 58;
            this.FootLeftY.Tag = "21";
            // 
            // FootLeftX
            // 
            this.FootLeftX.Location = new System.Drawing.Point(152, 450);
            this.FootLeftX.Name = "FootLeftX";
            this.FootLeftX.Size = new System.Drawing.Size(60, 20);
            this.FootLeftX.TabIndex = 57;
            this.FootLeftX.Tag = "20";
            // 
            // AnkleLeftZ
            // 
            this.AnkleLeftZ.Location = new System.Drawing.Point(282, 425);
            this.AnkleLeftZ.Name = "AnkleLeftZ";
            this.AnkleLeftZ.Size = new System.Drawing.Size(60, 20);
            this.AnkleLeftZ.TabIndex = 55;
            this.AnkleLeftZ.Tag = "12";
            // 
            // AnkleLeftY
            // 
            this.AnkleLeftY.Location = new System.Drawing.Point(217, 425);
            this.AnkleLeftY.Name = "AnkleLeftY";
            this.AnkleLeftY.Size = new System.Drawing.Size(60, 20);
            this.AnkleLeftY.TabIndex = 54;
            this.AnkleLeftY.Tag = "11";
            // 
            // AnkleLeftX
            // 
            this.AnkleLeftX.Location = new System.Drawing.Point(152, 425);
            this.AnkleLeftX.Name = "AnkleLeftX";
            this.AnkleLeftX.Size = new System.Drawing.Size(60, 20);
            this.AnkleLeftX.TabIndex = 53;
            this.AnkleLeftX.Tag = "10";
            // 
            // KneeLeftZ
            // 
            this.KneeLeftZ.Location = new System.Drawing.Point(282, 400);
            this.KneeLeftZ.Name = "KneeLeftZ";
            this.KneeLeftZ.Size = new System.Drawing.Size(60, 20);
            this.KneeLeftZ.TabIndex = 51;
            this.KneeLeftZ.Tag = "2";
            // 
            // KneeLeftY
            // 
            this.KneeLeftY.Location = new System.Drawing.Point(217, 400);
            this.KneeLeftY.Name = "KneeLeftY";
            this.KneeLeftY.Size = new System.Drawing.Size(60, 20);
            this.KneeLeftY.TabIndex = 50;
            this.KneeLeftY.Tag = "1";
            // 
            // KneeLeftX
            // 
            this.KneeLeftX.Location = new System.Drawing.Point(152, 400);
            this.KneeLeftX.Name = "KneeLeftX";
            this.KneeLeftX.Size = new System.Drawing.Size(60, 20);
            this.KneeLeftX.TabIndex = 49;
            this.KneeLeftX.Tag = "0";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(14, 476);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(89, 13);
            this.label9.TabIndex = 60;
            this.label9.Text = "HIPRIGHT 17:";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(15, 403);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(92, 13);
            this.label10.TabIndex = 48;
            this.label10.Text = "KNEELEFT 14:";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.Location = new System.Drawing.Point(15, 450);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(92, 13);
            this.label11.TabIndex = 56;
            this.label11.Text = "FOOTLEFT 16:";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.Location = new System.Drawing.Point(15, 426);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(99, 13);
            this.label12.TabIndex = 52;
            this.label12.Text = "ANKLELEFT 15:";
            // 
            // HipLeftZ
            // 
            this.HipLeftZ.Location = new System.Drawing.Point(282, 375);
            this.HipLeftZ.Name = "HipLeftZ";
            this.HipLeftZ.Size = new System.Drawing.Size(60, 20);
            this.HipLeftZ.TabIndex = 47;
            this.HipLeftZ.Tag = "32";
            // 
            // HipLeftY
            // 
            this.HipLeftY.Location = new System.Drawing.Point(217, 375);
            this.HipLeftY.Name = "HipLeftY";
            this.HipLeftY.Size = new System.Drawing.Size(60, 20);
            this.HipLeftY.TabIndex = 46;
            this.HipLeftY.Tag = "31";
            // 
            // HipLeftX
            // 
            this.HipLeftX.Location = new System.Drawing.Point(152, 375);
            this.HipLeftX.Name = "HipLeftX";
            this.HipLeftX.Size = new System.Drawing.Size(60, 20);
            this.HipLeftX.TabIndex = 45;
            this.HipLeftX.Tag = "30";
            // 
            // HandTipRightZ
            // 
            this.HandTipRightZ.Location = new System.Drawing.Point(282, 350);
            this.HandTipRightZ.Name = "HandTipRightZ";
            this.HandTipRightZ.Size = new System.Drawing.Size(60, 20);
            this.HandTipRightZ.TabIndex = 43;
            this.HandTipRightZ.Tag = "22";
            // 
            // HandTipRightY
            // 
            this.HandTipRightY.Location = new System.Drawing.Point(217, 350);
            this.HandTipRightY.Name = "HandTipRightY";
            this.HandTipRightY.Size = new System.Drawing.Size(60, 20);
            this.HandTipRightY.TabIndex = 42;
            this.HandTipRightY.Tag = "21";
            // 
            // HandTipRightX
            // 
            this.HandTipRightX.Location = new System.Drawing.Point(152, 350);
            this.HandTipRightX.Name = "HandTipRightX";
            this.HandTipRightX.Size = new System.Drawing.Size(60, 20);
            this.HandTipRightX.TabIndex = 41;
            this.HandTipRightX.Tag = "20";
            // 
            // WristRightZ
            // 
            this.WristRightZ.Location = new System.Drawing.Point(282, 325);
            this.WristRightZ.Name = "WristRightZ";
            this.WristRightZ.Size = new System.Drawing.Size(60, 20);
            this.WristRightZ.TabIndex = 39;
            this.WristRightZ.Tag = "12";
            // 
            // WristRightY
            // 
            this.WristRightY.Location = new System.Drawing.Point(217, 325);
            this.WristRightY.Name = "WristRightY";
            this.WristRightY.Size = new System.Drawing.Size(60, 20);
            this.WristRightY.TabIndex = 38;
            this.WristRightY.Tag = "11";
            // 
            // WristRightX
            // 
            this.WristRightX.Location = new System.Drawing.Point(152, 325);
            this.WristRightX.Name = "WristRightX";
            this.WristRightX.Size = new System.Drawing.Size(60, 20);
            this.WristRightX.TabIndex = 37;
            this.WristRightX.Tag = "10";
            // 
            // ElbowRightZ
            // 
            this.ElbowRightZ.Location = new System.Drawing.Point(282, 300);
            this.ElbowRightZ.Name = "ElbowRightZ";
            this.ElbowRightZ.Size = new System.Drawing.Size(60, 20);
            this.ElbowRightZ.TabIndex = 35;
            this.ElbowRightZ.Tag = "2";
            // 
            // ElbowRightY
            // 
            this.ElbowRightY.Location = new System.Drawing.Point(217, 300);
            this.ElbowRightY.Name = "ElbowRightY";
            this.ElbowRightY.Size = new System.Drawing.Size(60, 20);
            this.ElbowRightY.TabIndex = 34;
            this.ElbowRightY.Tag = "1";
            // 
            // ElbowRightX
            // 
            this.ElbowRightX.Location = new System.Drawing.Point(152, 300);
            this.ElbowRightX.Name = "ElbowRightX";
            this.ElbowRightX.Size = new System.Drawing.Size(60, 20);
            this.ElbowRightX.TabIndex = 33;
            this.ElbowRightX.Tag = "0";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.Location = new System.Drawing.Point(15, 375);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(80, 13);
            this.label13.TabIndex = 44;
            this.label13.Text = "HIPLEFT 13:";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.Location = new System.Drawing.Point(14, 300);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(112, 13);
            this.label14.TabIndex = 32;
            this.label14.Text = "ELBOWRIGHT 10:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.Location = new System.Drawing.Point(14, 353);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(123, 13);
            this.label15.TabIndex = 40;
            this.label15.Text = "HANDTIPRIGHT 12:";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.Location = new System.Drawing.Point(15, 322);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(109, 13);
            this.label16.TabIndex = 36;
            this.label16.Text = "WRISTRIGHT 11:";
            // 
            // HandTipLeftZ
            // 
            this.HandTipLeftZ.Location = new System.Drawing.Point(282, 250);
            this.HandTipLeftZ.Name = "HandTipLeftZ";
            this.HandTipLeftZ.Size = new System.Drawing.Size(60, 20);
            this.HandTipLeftZ.TabIndex = 31;
            this.HandTipLeftZ.Tag = "32";
            // 
            // HandTipLeftY
            // 
            this.HandTipLeftY.Location = new System.Drawing.Point(217, 250);
            this.HandTipLeftY.Name = "HandTipLeftY";
            this.HandTipLeftY.Size = new System.Drawing.Size(60, 20);
            this.HandTipLeftY.TabIndex = 30;
            this.HandTipLeftY.Tag = "31";
            // 
            // HandTipLeftX
            // 
            this.HandTipLeftX.Location = new System.Drawing.Point(152, 250);
            this.HandTipLeftX.Name = "HandTipLeftX";
            this.HandTipLeftX.Size = new System.Drawing.Size(60, 20);
            this.HandTipLeftX.TabIndex = 29;
            this.HandTipLeftX.Tag = "30";
            // 
            // WristLeftZ
            // 
            this.WristLeftZ.Location = new System.Drawing.Point(282, 225);
            this.WristLeftZ.Name = "WristLeftZ";
            this.WristLeftZ.Size = new System.Drawing.Size(60, 20);
            this.WristLeftZ.TabIndex = 27;
            this.WristLeftZ.Tag = "22";
            // 
            // WristLeftY
            // 
            this.WristLeftY.Location = new System.Drawing.Point(217, 225);
            this.WristLeftY.Name = "WristLeftY";
            this.WristLeftY.Size = new System.Drawing.Size(60, 20);
            this.WristLeftY.TabIndex = 26;
            this.WristLeftY.Tag = "21";
            // 
            // WristLeftX
            // 
            this.WristLeftX.Location = new System.Drawing.Point(152, 225);
            this.WristLeftX.Name = "WristLeftX";
            this.WristLeftX.Size = new System.Drawing.Size(60, 20);
            this.WristLeftX.TabIndex = 25;
            this.WristLeftX.Tag = "20";
            // 
            // ElbowLeftZ
            // 
            this.ElbowLeftZ.Location = new System.Drawing.Point(282, 200);
            this.ElbowLeftZ.Name = "ElbowLeftZ";
            this.ElbowLeftZ.Size = new System.Drawing.Size(60, 20);
            this.ElbowLeftZ.TabIndex = 23;
            this.ElbowLeftZ.Tag = "12";
            // 
            // ElbowLeftY
            // 
            this.ElbowLeftY.Location = new System.Drawing.Point(217, 200);
            this.ElbowLeftY.Name = "ElbowLeftY";
            this.ElbowLeftY.Size = new System.Drawing.Size(60, 20);
            this.ElbowLeftY.TabIndex = 22;
            this.ElbowLeftY.Tag = "11";
            // 
            // ElbowLeftX
            // 
            this.ElbowLeftX.Location = new System.Drawing.Point(152, 200);
            this.ElbowLeftX.Name = "ElbowLeftX";
            this.ElbowLeftX.Size = new System.Drawing.Size(60, 20);
            this.ElbowLeftX.TabIndex = 21;
            this.ElbowLeftX.Tag = "10";
            // 
            // ShoulderLeftZ
            // 
            this.ShoulderLeftZ.Location = new System.Drawing.Point(282, 175);
            this.ShoulderLeftZ.Name = "ShoulderLeftZ";
            this.ShoulderLeftZ.Size = new System.Drawing.Size(60, 20);
            this.ShoulderLeftZ.TabIndex = 19;
            this.ShoulderLeftZ.Tag = "2";
            // 
            // ShoulderLeftY
            // 
            this.ShoulderLeftY.Location = new System.Drawing.Point(217, 175);
            this.ShoulderLeftY.Name = "ShoulderLeftY";
            this.ShoulderLeftY.Size = new System.Drawing.Size(60, 20);
            this.ShoulderLeftY.TabIndex = 18;
            this.ShoulderLeftY.Tag = "1";
            // 
            // ShoulderLeftX
            // 
            this.ShoulderLeftX.Location = new System.Drawing.Point(152, 175);
            this.ShoulderLeftX.Name = "ShoulderLeftX";
            this.ShoulderLeftX.Size = new System.Drawing.Size(60, 20);
            this.ShoulderLeftX.TabIndex = 17;
            this.ShoulderLeftX.Tag = "0";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(14, 253);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(107, 13);
            this.label5.TabIndex = 28;
            this.label5.Text = "HANDTIPLEFT 8:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(14, 178);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 13);
            this.label6.TabIndex = 16;
            this.label6.Text = "SHOULDERLEFT 5:";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(14, 228);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(93, 13);
            this.label7.TabIndex = 24;
            this.label7.Text = "WRISTLEFT 7:";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(14, 203);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(96, 13);
            this.label8.TabIndex = 20;
            this.label8.Text = "ELBOWLEFT 6:";
            // 
            // HeadZ
            // 
            this.HeadZ.Location = new System.Drawing.Point(282, 150);
            this.HeadZ.Name = "HeadZ";
            this.HeadZ.Size = new System.Drawing.Size(60, 20);
            this.HeadZ.TabIndex = 15;
            this.HeadZ.Tag = "32";
            // 
            // HeadY
            // 
            this.HeadY.Location = new System.Drawing.Point(217, 150);
            this.HeadY.Name = "HeadY";
            this.HeadY.Size = new System.Drawing.Size(60, 20);
            this.HeadY.TabIndex = 14;
            this.HeadY.Tag = "31";
            // 
            // HeadX
            // 
            this.HeadX.Location = new System.Drawing.Point(152, 150);
            this.HeadX.Name = "HeadX";
            this.HeadX.Size = new System.Drawing.Size(60, 20);
            this.HeadX.TabIndex = 13;
            this.HeadX.Tag = "30";
            // 
            // NeckZ
            // 
            this.NeckZ.Location = new System.Drawing.Point(282, 125);
            this.NeckZ.Name = "NeckZ";
            this.NeckZ.Size = new System.Drawing.Size(60, 20);
            this.NeckZ.TabIndex = 11;
            this.NeckZ.Tag = "22";
            // 
            // NeckY
            // 
            this.NeckY.Location = new System.Drawing.Point(217, 125);
            this.NeckY.Name = "NeckY";
            this.NeckY.Size = new System.Drawing.Size(60, 20);
            this.NeckY.TabIndex = 10;
            this.NeckY.Tag = "21";
            // 
            // NeckX
            // 
            this.NeckX.Location = new System.Drawing.Point(152, 125);
            this.NeckX.Name = "NeckX";
            this.NeckX.Size = new System.Drawing.Size(60, 20);
            this.NeckX.TabIndex = 9;
            this.NeckX.Tag = "20";
            // 
            // SpineMidZ
            // 
            this.SpineMidZ.Location = new System.Drawing.Point(282, 100);
            this.SpineMidZ.Name = "SpineMidZ";
            this.SpineMidZ.Size = new System.Drawing.Size(60, 20);
            this.SpineMidZ.TabIndex = 7;
            this.SpineMidZ.Tag = "12";
            // 
            // SpineMidY
            // 
            this.SpineMidY.Location = new System.Drawing.Point(217, 100);
            this.SpineMidY.Name = "SpineMidY";
            this.SpineMidY.Size = new System.Drawing.Size(60, 20);
            this.SpineMidY.TabIndex = 6;
            this.SpineMidY.Tag = "11";
            // 
            // SpineMidX
            // 
            this.SpineMidX.Location = new System.Drawing.Point(152, 100);
            this.SpineMidX.Name = "SpineMidX";
            this.SpineMidX.Size = new System.Drawing.Size(60, 20);
            this.SpineMidX.TabIndex = 5;
            this.SpineMidX.Tag = "10";
            // 
            // SpineBaseZ
            // 
            this.SpineBaseZ.Location = new System.Drawing.Point(282, 75);
            this.SpineBaseZ.Name = "SpineBaseZ";
            this.SpineBaseZ.Size = new System.Drawing.Size(60, 20);
            this.SpineBaseZ.TabIndex = 3;
            this.SpineBaseZ.Tag = "2";
            // 
            // SpineBaseY
            // 
            this.SpineBaseY.Location = new System.Drawing.Point(217, 75);
            this.SpineBaseY.Name = "SpineBaseY";
            this.SpineBaseY.Size = new System.Drawing.Size(60, 20);
            this.SpineBaseY.TabIndex = 2;
            this.SpineBaseY.Tag = "1";
            // 
            // SpineBaseX
            // 
            this.SpineBaseX.Location = new System.Drawing.Point(152, 75);
            this.SpineBaseX.Name = "SpineBaseX";
            this.SpineBaseX.Size = new System.Drawing.Size(60, 20);
            this.SpineBaseX.TabIndex = 1;
            this.SpineBaseX.Tag = "0";
            // 
            // modelPoint4Label
            // 
            this.modelPoint4Label.AutoSize = true;
            this.modelPoint4Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelPoint4Label.Location = new System.Drawing.Point(14, 153);
            this.modelPoint4Label.Name = "modelPoint4Label";
            this.modelPoint4Label.Size = new System.Drawing.Size(56, 13);
            this.modelPoint4Label.TabIndex = 12;
            this.modelPoint4Label.Text = "HEAD 4:";
            // 
            // modelPoint1Label
            // 
            this.modelPoint1Label.AutoSize = true;
            this.modelPoint1Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelPoint1Label.Location = new System.Drawing.Point(14, 78);
            this.modelPoint1Label.Name = "modelPoint1Label";
            this.modelPoint1Label.Size = new System.Drawing.Size(91, 13);
            this.modelPoint1Label.TabIndex = 0;
            this.modelPoint1Label.Text = "SPINEBASE 1:";
            // 
            // modelPoint3Label
            // 
            this.modelPoint3Label.AutoSize = true;
            this.modelPoint3Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelPoint3Label.Location = new System.Drawing.Point(14, 128);
            this.modelPoint3Label.Name = "modelPoint3Label";
            this.modelPoint3Label.Size = new System.Drawing.Size(55, 13);
            this.modelPoint3Label.TabIndex = 8;
            this.modelPoint3Label.Text = "NECK 3:";
            // 
            // modelPoint2Label
            // 
            this.modelPoint2Label.AutoSize = true;
            this.modelPoint2Label.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.modelPoint2Label.Location = new System.Drawing.Point(14, 103);
            this.modelPoint2Label.Name = "modelPoint2Label";
            this.modelPoint2Label.Size = new System.Drawing.Size(82, 13);
            this.modelPoint2Label.TabIndex = 4;
            this.modelPoint2Label.Text = "SPINEMID 2:";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(6, 53);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(73, 16);
            this.label2.TabIndex = 86;
            this.label2.Text = "Person 1:";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.pCount);
            this.groupBox1.Controls.Add(this.P6);
            this.groupBox1.Controls.Add(this.P6ID);
            this.groupBox1.Controls.Add(this.P5);
            this.groupBox1.Controls.Add(this.P5ID);
            this.groupBox1.Controls.Add(this.P4);
            this.groupBox1.Controls.Add(this.P4ID);
            this.groupBox1.Controls.Add(this.P3);
            this.groupBox1.Controls.Add(this.P3ID);
            this.groupBox1.Controls.Add(this.P2);
            this.groupBox1.Controls.Add(this.P2ID);
            this.groupBox1.Controls.Add(this.label27);
            this.groupBox1.Controls.Add(this.P1);
            this.groupBox1.Controls.Add(this.label28);
            this.groupBox1.Controls.Add(this.P1ID);
            this.groupBox1.Controls.Add(this.label21);
            this.groupBox1.Controls.Add(this.label20);
            this.groupBox1.Controls.Add(this.label17);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Location = new System.Drawing.Point(1511, 9);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(359, 214);
            this.groupBox1.TabIndex = 87;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Persons IN View";
            // 
            // pCount
            // 
            this.pCount.AutoSize = true;
            this.pCount.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pCount.Location = new System.Drawing.Point(24, 26);
            this.pCount.Name = "pCount";
            this.pCount.Size = new System.Drawing.Size(14, 13);
            this.pCount.TabIndex = 125;
            this.pCount.Text = "0";
            // 
            // P6
            // 
            this.P6.Location = new System.Drawing.Point(214, 178);
            this.P6.Name = "P6";
            this.P6.Size = new System.Drawing.Size(125, 20);
            this.P6.TabIndex = 124;
            // 
            // P6ID
            // 
            this.P6ID.Location = new System.Drawing.Point(85, 178);
            this.P6ID.Name = "P6ID";
            this.P6ID.Size = new System.Drawing.Size(123, 20);
            this.P6ID.TabIndex = 123;
            // 
            // P5
            // 
            this.P5.Location = new System.Drawing.Point(214, 153);
            this.P5.Name = "P5";
            this.P5.Size = new System.Drawing.Size(125, 20);
            this.P5.TabIndex = 122;
            // 
            // P5ID
            // 
            this.P5ID.Location = new System.Drawing.Point(85, 153);
            this.P5ID.Name = "P5ID";
            this.P5ID.Size = new System.Drawing.Size(123, 20);
            this.P5ID.TabIndex = 121;
            // 
            // P4
            // 
            this.P4.Location = new System.Drawing.Point(214, 131);
            this.P4.Name = "P4";
            this.P4.Size = new System.Drawing.Size(125, 20);
            this.P4.TabIndex = 120;
            // 
            // P4ID
            // 
            this.P4ID.Location = new System.Drawing.Point(85, 131);
            this.P4ID.Name = "P4ID";
            this.P4ID.Size = new System.Drawing.Size(123, 20);
            this.P4ID.TabIndex = 119;
            // 
            // P3
            // 
            this.P3.Location = new System.Drawing.Point(214, 108);
            this.P3.Name = "P3";
            this.P3.Size = new System.Drawing.Size(125, 20);
            this.P3.TabIndex = 118;
            // 
            // P3ID
            // 
            this.P3ID.Location = new System.Drawing.Point(85, 108);
            this.P3ID.Name = "P3ID";
            this.P3ID.Size = new System.Drawing.Size(123, 20);
            this.P3ID.TabIndex = 117;
            // 
            // P2
            // 
            this.P2.Location = new System.Drawing.Point(214, 82);
            this.P2.Name = "P2";
            this.P2.Size = new System.Drawing.Size(125, 20);
            this.P2.TabIndex = 116;
            // 
            // P2ID
            // 
            this.P2ID.Location = new System.Drawing.Point(85, 82);
            this.P2ID.Name = "P2ID";
            this.P2ID.Size = new System.Drawing.Size(123, 20);
            this.P2ID.TabIndex = 115;
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(271, 26);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(41, 13);
            this.label27.TabIndex = 114;
            this.label27.Text = "Identity";
            // 
            // P1
            // 
            this.P1.Location = new System.Drawing.Point(214, 53);
            this.P1.Name = "P1";
            this.P1.Size = new System.Drawing.Size(125, 20);
            this.P1.TabIndex = 113;
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(114, 26);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(60, 13);
            this.label28.TabIndex = 112;
            this.label28.Text = "TrackingID";
            // 
            // P1ID
            // 
            this.P1ID.Location = new System.Drawing.Point(85, 53);
            this.P1ID.Name = "P1ID";
            this.P1ID.Size = new System.Drawing.Size(123, 20);
            this.P1ID.TabIndex = 111;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.Location = new System.Drawing.Point(8, 156);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(73, 16);
            this.label21.TabIndex = 91;
            this.label21.Text = "Person 5:";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.Location = new System.Drawing.Point(8, 131);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(73, 16);
            this.label20.TabIndex = 90;
            this.label20.Text = "Person 4:";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.Location = new System.Drawing.Point(8, 181);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(73, 16);
            this.label17.TabIndex = 89;
            this.label17.Text = "Person 6:";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(6, 81);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(73, 16);
            this.label4.TabIndex = 88;
            this.label4.Text = "Person 2:";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(6, 106);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(73, 16);
            this.label3.TabIndex = 87;
            this.label3.Text = "Person 3:";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(655, 598);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(107, 20);
            this.label31.TabIndex = 88;
            this.label31.Text = "Body Exists:";
            // 
            // BE
            // 
            this.BE.AutoSize = true;
            this.BE.Font = new System.Drawing.Font("MS Reference Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BE.Location = new System.Drawing.Point(781, 596);
            this.BE.Name = "BE";
            this.BE.Size = new System.Drawing.Size(75, 24);
            this.BE.TabIndex = 89;
            this.BE.Text = "FALSE";
            // 
            // button1
            // 
            this.button1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.button1.Location = new System.Drawing.Point(865, 18);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 90;
            this.button1.Text = "wide";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1370, 715);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.BE);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.modelPointsGroupBox);
            this.Controls.Add(this.BF);
            this.Controls.Add(this.CF);
            this.Controls.Add(this.connect);
            this.Controls.Add(this.BFlabel);
            this.Controls.Add(this.CFlabel);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.pb);
            this.Controls.Add(this.groupBox12);
            this.Name = "Form1";
            this.Text = "Form1";
            this.groupBox12.ResumeLayout(false);
            this.groupBox12.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb)).EndInit();
            this.modelPointsGroupBox.ResumeLayout(false);
            this.modelPointsGroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox12;
        private System.Windows.Forms.TextBox LegLength;
        private System.Windows.Forms.TextBox LeftLowerLegValue;
        private System.Windows.Forms.TextBox RightThighValue;
        private System.Windows.Forms.CheckBox checkBox15;
        private System.Windows.Forms.TextBox NeckValue;
        private System.Windows.Forms.CheckBox checkBox16;
        private System.Windows.Forms.TextBox RightLowerLegValue;
        private System.Windows.Forms.CheckBox checkBox11;
        private System.Windows.Forms.TextBox HeightValue;
        private System.Windows.Forms.CheckBox checkBox12;
        private System.Windows.Forms.TextBox LeftThighValue;
        private System.Windows.Forms.CheckBox checkBox13;
        private System.Windows.Forms.TextBox TorsoValue;
        private System.Windows.Forms.CheckBox checkBox14;
        private System.Windows.Forms.TextBox LowerSpineValue;
        private System.Windows.Forms.CheckBox checkBox7;
        private System.Windows.Forms.TextBox UpperSpineValue;
        private System.Windows.Forms.CheckBox checkBox8;
        private System.Windows.Forms.TextBox LeftUpperArmValue;
        private System.Windows.Forms.CheckBox checkBox9;
        private System.Windows.Forms.TextBox RightForeArmValue;
        private System.Windows.Forms.CheckBox checkBox10;
        private System.Windows.Forms.TextBox LeftForeArmValue;
        private System.Windows.Forms.CheckBox checkBox5;
        private System.Windows.Forms.TextBox RightUpperArmValue;
        private System.Windows.Forms.CheckBox checkBox6;
        private System.Windows.Forms.CheckBox checkBox3;
        private System.Windows.Forms.CheckBox checkBox4;
        private System.Windows.Forms.PictureBox pb;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label CFlabel;
        private System.Windows.Forms.Label BFlabel;
        private System.Windows.Forms.Button connect;
        private System.Windows.Forms.Label CF;
        private System.Windows.Forms.Label BF;
        private System.Windows.Forms.GroupBox modelPointsGroupBox;
        private System.Windows.Forms.TextBox KneeRightZ;
        private System.Windows.Forms.TextBox KneeRightY;
        private System.Windows.Forms.TextBox KneeRightX;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.TextBox ShoulderRightZ;
        private System.Windows.Forms.TextBox ShoulderRightY;
        private System.Windows.Forms.TextBox ShoulderRightX;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox ThumbRightZ;
        private System.Windows.Forms.TextBox ThumbRightY;
        private System.Windows.Forms.TextBox ThumbRightX;
        private System.Windows.Forms.TextBox ThumbLeftZ;
        private System.Windows.Forms.TextBox ThumbLeftY;
        private System.Windows.Forms.TextBox ThumbLeftX;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox SpineShoulderZ;
        private System.Windows.Forms.TextBox SpineShoulderY;
        private System.Windows.Forms.TextBox SpineShoulderX;
        private System.Windows.Forms.TextBox FootRightZ;
        private System.Windows.Forms.TextBox FootRightY;
        private System.Windows.Forms.TextBox FootRightX;
        private System.Windows.Forms.TextBox AnkleRightZ;
        private System.Windows.Forms.TextBox AnkleRightY;
        private System.Windows.Forms.TextBox AnkleRightX;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox HipRightZ;
        private System.Windows.Forms.TextBox HipRightY;
        private System.Windows.Forms.TextBox HipRightX;
        private System.Windows.Forms.TextBox FootLeftZ;
        private System.Windows.Forms.TextBox FootLeftY;
        private System.Windows.Forms.TextBox FootLeftX;
        private System.Windows.Forms.TextBox AnkleLeftZ;
        private System.Windows.Forms.TextBox AnkleLeftY;
        private System.Windows.Forms.TextBox AnkleLeftX;
        private System.Windows.Forms.TextBox KneeLeftZ;
        private System.Windows.Forms.TextBox KneeLeftY;
        private System.Windows.Forms.TextBox KneeLeftX;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox HipLeftZ;
        private System.Windows.Forms.TextBox HipLeftY;
        private System.Windows.Forms.TextBox HipLeftX;
        private System.Windows.Forms.TextBox HandTipRightZ;
        private System.Windows.Forms.TextBox HandTipRightY;
        private System.Windows.Forms.TextBox HandTipRightX;
        private System.Windows.Forms.TextBox WristRightZ;
        private System.Windows.Forms.TextBox WristRightY;
        private System.Windows.Forms.TextBox WristRightX;
        private System.Windows.Forms.TextBox ElbowRightZ;
        private System.Windows.Forms.TextBox ElbowRightY;
        private System.Windows.Forms.TextBox ElbowRightX;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.TextBox HandTipLeftZ;
        private System.Windows.Forms.TextBox HandTipLeftY;
        private System.Windows.Forms.TextBox HandTipLeftX;
        private System.Windows.Forms.TextBox WristLeftZ;
        private System.Windows.Forms.TextBox WristLeftY;
        private System.Windows.Forms.TextBox WristLeftX;
        private System.Windows.Forms.TextBox ElbowLeftZ;
        private System.Windows.Forms.TextBox ElbowLeftY;
        private System.Windows.Forms.TextBox ElbowLeftX;
        private System.Windows.Forms.TextBox ShoulderLeftZ;
        private System.Windows.Forms.TextBox ShoulderLeftY;
        private System.Windows.Forms.TextBox ShoulderLeftX;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox HeadZ;
        private System.Windows.Forms.TextBox HeadY;
        private System.Windows.Forms.TextBox HeadX;
        private System.Windows.Forms.TextBox NeckZ;
        private System.Windows.Forms.TextBox NeckY;
        private System.Windows.Forms.TextBox NeckX;
        private System.Windows.Forms.TextBox SpineMidZ;
        private System.Windows.Forms.TextBox SpineMidY;
        private System.Windows.Forms.TextBox SpineMidX;
        private System.Windows.Forms.TextBox SpineBaseZ;
        private System.Windows.Forms.TextBox SpineBaseY;
        private System.Windows.Forms.TextBox SpineBaseX;
        private System.Windows.Forms.Label modelPoint4Label;
        private System.Windows.Forms.Label modelPoint1Label;
        private System.Windows.Forms.Label modelPoint3Label;
        private System.Windows.Forms.Label modelPoint2Label;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label pCount;
        private System.Windows.Forms.TextBox P6;
        private System.Windows.Forms.TextBox P6ID;
        private System.Windows.Forms.TextBox P5;
        private System.Windows.Forms.TextBox P5ID;
        private System.Windows.Forms.TextBox P4;
        private System.Windows.Forms.TextBox P4ID;
        private System.Windows.Forms.TextBox P3;
        private System.Windows.Forms.TextBox P3ID;
        private System.Windows.Forms.TextBox P2;
        private System.Windows.Forms.TextBox P2ID;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.TextBox P1;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.TextBox P1ID;
        private System.Windows.Forms.TextBox trackingID;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label BE;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label32;
    }
}

